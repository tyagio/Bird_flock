using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Member
{
    override protected void Running()
    {
        acceleration += Wander() * conf.WanderPriority;
        acceleration += Cohesion() * conf.CohesionPriority*2;
        acceleration = Vector3.ClampMagnitude(acceleration, conf.max_acceleration);
    }

    override protected void Start()
    {
        level = FindObjectOfType<Level>();
        conf = FindObjectOfType<Member_config>();
        position = transform.position;
        prev_position = position;
        velocity = new Vector3(Random.Range(-3f, 3f), Random.Range(-3f, 3f), 0);
        InvokeRepeating("Running", 0f, conf.recalc_time);
       
    }

    override protected void Update()
    {
        velocity += (acceleration * Time.deltaTime);
        velocity = Vector3.ClampMagnitude(velocity, conf.max_velocity);
        position += (velocity * Time.deltaTime);
        WrapAround(ref position, -level.bounds, level.bounds);
        transform.position = position;
    }
}
