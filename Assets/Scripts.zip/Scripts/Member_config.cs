using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Member_config : MonoBehaviour
{
    public float maxfov = 180;
    public float max_acceleration;
    public float max_velocity;
    public float recalc_time;
    public float WanderJitter;
    public float WanderRadius;
    public float WanderDistance;
    public float WanderPriority;

    public float CohesionRadius;
    public float CohesionPriority;

    public float AlignmentRadius;
    public float AlignmentPriority;

    public float SeperationRadius;
    public float SeperationPriority;

    public float AvoidanceRadius;
    public float AvoidancePriority;


}
